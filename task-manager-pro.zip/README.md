# 🚀 Task Manager Pro

## Features
- Full CRUD
- Edit tasks
- Filters (All / Completed / Pending)
- LocalStorage persistence
- Clean UI

## Run
Backend:
cd backend && npm install && npm start

Frontend:
cd frontend && npm install && npm run dev

## Notes
- Designed for technical assignment
- Focus on clean structure + usability
