import { useEffect, useState } from "react";
import axios from "axios";
import "./styles.css";

const API = "http://localhost:5000/tasks";

export default function App() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState("");
  const [filter, setFilter] = useState("all");

  const fetchTasks = async () => {
    const res = await axios.get(API);
    setTasks(res.data);
    localStorage.setItem("tasks", JSON.stringify(res.data));
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  const addTask = async () => {
    if (!title.trim()) return;
    await axios.post(API, { title });
    setTitle("");
    fetchTasks();
  };

  const toggleTask = async (task) => {
    await axios.patch(`${API}/${task.id}`, { completed: !task.completed });
    fetchTasks();
  };

  const deleteTask = async (id) => {
    await axios.delete(`${API}/${id}`);
    fetchTasks();
  };

  const editTask = async (task) => {
    const newTitle = prompt("Edit task", task.title);
    if (!newTitle) return;
    await axios.patch(`${API}/${task.id}`, { title: newTitle });
    fetchTasks();
  };

  const filtered = tasks.filter(t => {
    if (filter === "completed") return t.completed;
    if (filter === "pending") return !t.completed;
    return true;
  });

  return (
    <div className="container">
      <h1>🚀 Task Manager Pro</h1>

      <div className="input-group">
        <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Add task"/>
        <button onClick={addTask}>Add</button>
      </div>

      <div className="filters">
        <button onClick={() => setFilter("all")}>All</button>
        <button onClick={() => setFilter("completed")}>Completed</button>
        <button onClick={() => setFilter("pending")}>Pending</button>
      </div>

      <ul>
        {filtered.map(task => (
          <li key={task.id} className={task.completed ? "done" : ""}>
            <span onClick={() => toggleTask(task)}>{task.title}</span>
            <div>
              <button onClick={() => editTask(task)}>✏️</button>
              <button onClick={() => deleteTask(task.id)}>❌</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}
